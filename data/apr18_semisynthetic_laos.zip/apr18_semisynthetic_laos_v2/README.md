# APR18-based semi-synthetic LAOS benchmark v2

This package uses the measured APR18 LAOS record at omega=1 rad/s and gamma0=10 as a common baseline. It contains 1,995 observations over approximately 40 s at about 50 Hz. The control file is unchanged. Three test cases introduce gradual stress-amplitude changes of 10%, 20% and 30% after the same known onset at 15 s.

## Construction

stress_case(t) = stress_APR18(t) * [1 + alpha*q(t)]

q(t) = 0 before 15 s, and q(t) = 1 - exp(-((t-15)/5)^2) afterwards.

The measured APR18 strain, derived shear rate, time grid and pre-existing experimental variability are retained. No extra noise is added. Using one baseline and one onset isolates the effect of change magnitude.

## Files

- observable/control.csv: unchanged APR18 LAOS control
- observable/change_10pct.csv: gradual 10% amplitude increase
- observable/change_20pct.csv: gradual 20% amplitude increase
- observable/change_30pct.csv: gradual 30% amplitude increase
- truth/: injected state and baseline values kept separate from observable inputs
- case_summary.csv: case-level parameters and stress ranges
- metadata.json: full provenance, formula and intended evaluation workflow

## Recommended t-ESSTV evaluation

Fit t-ESSTV using APR18 steady-state and Step data, freeze the fitted parameters, and predict all four files. Set the residual or rolling-RMSE threshold using only the control. Apply the frozen threshold to the three change cases. Report ground-truth onset, detected onset, detection delay, pre-onset false alarms and the minimum reliably detectable change magnitude.

## Scope

These files contain controlled mechanical perturbations for sensitivity testing. They do not claim that a 10%, 20% or 30% stress increase is a clinical clotting label.

Sources: APR18 Mendeley Data, DOI 10.17632/6jjryg2f8v.1; Armstrong et al. (2022), DOI 10.3389/fphy.2022.889065.
