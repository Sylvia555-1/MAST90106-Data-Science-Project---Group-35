# APR18 t-ESSTV semi-synthetic change-detection pipeline

This package performs one consistent experiment:

1. Fit t-ESSTV parameters using the real APR18 steady-state and Step data.
2. Freeze the fitted parameters.
3. Predict four APR18-based LAOS signals: one unchanged control and three
   signals containing gradual 10%, 20% and 30% stress-amplitude changes.
4. Set a rolling-RMSE threshold using only the control.
5. Apply the frozen threshold to all cases and report detected onset, delay
   and false alarms.

The injected changes begin at 15 s. They are controlled mechanical changes,
not clinical clot labels. Because the whole stress waveform is scaled, these
data do not impose a G'-G'' crossover.

## Run in WSL

Open a terminal in this extracted folder and run:

```bash
python3 -m pip install -r requirements.txt
python3 run_pipeline.py --profile quick
```

For the final, slower optimisation:

```bash
python3 run_pipeline.py --profile full
```

To rerun prediction without fitting again:

```bash
python3 run_pipeline.py --skip-fit
```

## Runtime outputs

The scripts create `results/` when run. Important files are:

- `results/fit/selected_fit.json`: fitted APR18 parameters.
- `results/laos_change_detection/detection_summary.csv`: main quantitative results.
- `results/laos_change_detection/*_prediction.csv`: stress, residual, rolling RMSE and lambda.
- `results/laos_change_detection/figures/stress_observed_vs_tesstv.png`.
- `results/laos_change_detection/figures/rolling_rmse_and_detection.png`.

No precomputed results are included in this ZIP.

## Data construction

The control is the measured APR18 LAOS signal at omega = 1 rad/s and gamma0 =
10. The other cases use

```text
stress_case(t) = stress_APR18(t) * [1 + alpha*q(t)]
q(t) = 0                                      for t < 15 s
q(t) = 1 - exp(-((t - 15)/5)^2)              for t >= 15 s
```

where alpha is 0, 0.10, 0.20 or 0.30. No additional random noise is added;
the measured APR18 variability is retained.

Data source: APR18 Mendeley Data, DOI 10.17632/6jjryg2f8v.1. Model reference:
Armstrong et al. (2022), Frontiers in Physics, DOI 10.3389/fphy.2022.889065.
