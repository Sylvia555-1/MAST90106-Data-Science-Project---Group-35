Parameter | Units | Armstrong et al. (2022) Donor 5 | Our fitted APR18
--- | --- | ---: | ---:
mu0_c | Pa s | 0.0138 | 0.00967435
muinf_c | Pa s | 0.0054 | 0.00528847
tau_c | s | 0.029 | 0.0153172
tau_break | s | 1.582 | 2.10371
tau_aggr | s | 0.192 | 1.19607
mu_r | Pa s | 0.099 | 0.101964
sigma_y0 | Pa | 0.0039 | 0.00474935
tau_lambda | s | 1.4582 | 1.39239
G_r | Pa | 0.2646 | 0.442179
G_c | Pa | 0.5138 | 1.15151
