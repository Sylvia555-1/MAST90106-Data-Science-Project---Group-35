"""Scalar-initialized tensor t-ESSTV fitting core; no data-dependent fitting on import.

Frontiers 2022 Eq2-8, Tables1/3, Eq10-12. The corrected negative q branch is
from the source audit (JoR 2022 / PoF 2023). Backstress retains the PRINTED
signed gamma_e convention: full reversal symmetry remains unresolved.

States: lambda, gamma_e, Cxy, Cxx, Rxy, Rxx. Ryy=Rzz=0 is invariant for the
specified equilibrated positive prehistory, not an arbitrary tensor reduction.
The scalar model uses the same background/kinematics and sets the last state
to zero. It uses Eq6's signed scalar stress, not tensor equivalent stress.
"""
from dataclasses import asdict
import time

import numpy as np
try:
    from numba import njit
except ImportError:  # Optional acceleration; equations are unchanged.
    def njit(*args, **kwargs):
        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return args[0]
        def decorate(function):
            return function
        return decorate
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

from tesstv_paper_reproduction.model import Params

NAMES = ('mu0_c', 'muinf_c', 'tau_c', 'tau_break', 'tau_aggr', 'mu_r',
         'sigma_y0', 'tau_lambda', 'G_r', 'G_c')
# First optimizer coordinate is mu0-muinf, guaranteeing shear thinning.
# Computational search bounds, NOT published physiological confidence limits.
BOUNDS = np.array([(1e-5, .06), (.001, .01), (.0003, .5), (.02, 10.),
                   (1e-9, 2.), (.001, .5), (1e-6, .02), (.03, 15.),
                   (.01, 2.), (.03, 5.)])
LOG_LO, LOG_SPAN = np.log(BOUNDS[:, 0]), np.log(BOUNDS[:, 1]/BOUNDS[:, 0])
PUBLISHED_MEAN = Params(.00761, .00357, .03299, .86984, .05879, .03528,
                        .00276, 1.130, .151, .591)


def pack(p):
    a = np.array([getattr(p, n) for n in NAMES])
    a[0] -= a[1]
    return (np.log(a)-LOG_LO)/LOG_SPAN


def unpack(z):
    z = np.asarray(z, float)
    if z.shape != (10,) or not np.isfinite(z).all() or (z < 0).any() or (z > 1).any():
        raise ValueError('Optimizer coordinates must be ten values in [0,1].')
    a = np.exp(LOG_LO+z*LOG_SPAN)
    a[0] += a[1]
    return Params(*a)  # gamma0=1, d=.5, m=1.5 remain fixed.


def vector(p):
    return np.array([getattr(p, n) for n in NAMES], float)


@njit(cache=True)
def rate_kinematics(g, lam, ge, a):
    if lam <= 0 or not np.isfinite(lam):
        raise ValueError('lambda must be positive; no clipping.')
    h = ge/lam  # gamma0=1
    denominator = 2-h if g >= 0 else 2+h
    if denominator <= 0:
        raise ValueError('Invalid plastic-rate denominator.')
    q = g/denominator
    dl = ((1-lam)*(1+np.sqrt(a[4]*abs(q)))-a[3]*abs(q)*lam)/a[7]
    de = q-h*abs(q)+h*min(dl, 0.)
    return dl, de, q


@njit(cache=True)
def rhs_array(y, g, a, tensor):
    lam, ge, cxy, cxx, rxy, rxx = y
    dl, de, q = rate_kinematics(g, lam, ge, a)
    if cxx < 0 or not np.isfinite(cxx):
        raise ValueError('Cxx must be nonnegative; no clipping.')
    root = np.sqrt(a[9]*cxx/2.)
    b, c = a[2]*root-a[0], -a[1]*a[2]*root
    disc = np.hypot(b, 2*np.sqrt(-c))
    eta = (-b+disc)/2 if b <= 0 else -2*c/(b+disc)
    back = a[6]*ge
    eq = np.hypot(rxy, rxx/np.sqrt(3.)) if tensor else abs(rxy)
    diff = abs(eq-back) if tensor else abs(rxy-back)
    if eq == 0:
        if back != 0:
            raise ValueError('Zero stress with nonzero backstress is singular.')
        rx_relax, xx_relax = 0., 0.
    else:
        # Normalize the tensor before multiplication, avoiding norm-square underflow.
        k = a[8]*diff/(a[5]*np.sqrt(lam))
        rx_relax, xx_relax = k*(rxy/eq), k*(rxx/eq)
    return np.array([dl, de, a[9]*(g-cxy/eta),
                     2*g*cxy-a[9]*cxx/eta,
                     lam*a[8]*g-rx_relax,
                     2*g*rxy-xx_relax if tensor else 0.])


def equilibrium(g, p, tensor=True):
    if g <= 0:
        raise ValueError('This fit initializes only at positive pre-shear equilibrium.')
    build = 1+np.sqrt(p.tau_aggr*g)
    lam = build/(build+p.tau_break*g)
    eta = p.muinf_c+(p.mu0_c-p.muinf_c)/(1+p.tau_c*g)
    visc, back = p.mu_r*lam**1.5*g, p.sigma_y0*lam
    if tensor:
        f = lambda s: s-visc-back/np.hypot(1., 2*s/(np.sqrt(3.)*lam*p.G_r))
        r = brentq(f, visc, visc+back, xtol=5e-16, rtol=1e-14)
    else:
        r = visc+back
    return np.array([lam, lam, eta*g, 2*(eta*g)**2/p.G_c,
                     r, 2*r*r/(lam*p.G_r) if tensor else 0.])


def steady(rates, p, tensor=True):
    if not tensor:
        g = np.asarray(rates)
        build = 1+np.sqrt(p.tau_aggr*g)
        lam = build/(build+p.tau_break*g)
        eta = p.muinf_c+(p.mu0_c-p.muinf_c)/(1+p.tau_c*g)
        return eta*g+p.mu_r*lam**1.5*g+p.sigma_y0*lam
    return np.array([sum(equilibrium(float(g), p)[[2, 4]]) for g in rates])


def integrate(record, p, tensor=True, input_mode='measured', *,
              tight=False, initial=None, method='LSODA', max_rhs_calls=None,
              input_step_fraction=None):
    if input_mode not in ('measured', 'ideal'):
        raise ValueError('Explicit measured or ideal input is required.')
    t = record['time']
    g = record['rate']
    a = vector(p)
    state = equilibrium(record['pre'], p, tensor) if initial is None else np.asarray(initial).copy()
    y = np.empty((len(t), 6)); y[0] = state
    # Use small steps over the resolved input transient, allow adaptive long-time steps.
    # Final accepted fits are re-evaluated with stricter tolerances and Radau.
    ends = sorted(set([0., min(.06, t[-1]), min(.5, t[-1]), min(3., t[-1]), t[-1]]))
    nfev = 0
    rhs_calls = 0
    budget = max_rhs_calls if max_rhs_calls is not None else (300000 if tight else 30000)
    callback_failure = None
    dt_caps = (.001, .01, .1, 2.)
    observed_min_ge, observed_min_lambda = float(state[1]), float(state[0])
    for j, (left, right) in enumerate(zip(ends[:-1], ends[1:])):
        idx = np.flatnonzero((t > left) & (t <= right))
        evaluation = np.unique(np.r_[t[idx], right])
        def fun(x, z):
            nonlocal observed_min_ge, observed_min_lambda, rhs_calls, callback_failure
            # Do not propagate a Python exception across this runtime's Fortran
            # LSODA callback boundary (it can abort the interpreter). Mark the
            # entire solve invalid, return a finite placeholder to unwind safely,
            # and raise OUTSIDE solve_ivp. No placeholder output is ever returned.
            if callback_failure is not None:
                return np.zeros(6)
            rhs_calls += 1
            if rhs_calls > budget:
                callback_failure = RuntimeError('ODE RHS evaluation budget exceeded; proposal not evaluated.')
                return np.zeros(6)
            observed_min_ge = min(observed_min_ge, float(z[1]))
            observed_min_lambda = min(observed_min_lambda, float(z[0]))
            rate = np.interp(x, t, g) if input_mode == 'measured' else record['target']
            try:
                return rhs_array(z, rate, a, tensor)
            except (ValueError,RuntimeError,FloatingPointError,OverflowError) as exc:
                callback_failure = exc
                return np.zeros(6)
        cap = dt_caps[j]/(3 if tight else 1)
        if input_step_fraction is not None:
            if not 0 < input_step_fraction <= 1:
                raise ValueError('Input-step fraction must be in (0,1].')
            overlaps = (t[:-1] < right) & (t[1:] > left)
            cap = min(cap, input_step_fraction*float(np.min(np.diff(t)[overlaps])))
        sol = solve_ivp(fun, (left, right), state, t_eval=evaluation, method=method,
                        rtol=2e-9 if tight else 2e-6, atol=1e-12 if tight else 2e-10,
                        max_step=cap)
        if callback_failure is not None:
            raise callback_failure
        if not sol.success or not np.isfinite(sol.y).all():
            raise RuntimeError('ODE integration failed: '+sol.message)
        if (sol.y[0] <= 0).any() or (sol.y[0] > 1+2e-5).any() or (sol.y[3] < 0).any():
            raise ValueError('Integrated state outside physical support.')
        if np.max(np.abs(sol.y[1]/sol.y[0])) > 1+2e-5:
            raise ValueError('Elastic strain outside structure-dependent bound.')
        y[idx] = sol.y[:, np.searchsorted(evaluation, t[idx])].T
        state = sol.y[:, -1]
        nfev += sol.nfev
    rate = g if input_mode == 'measured' else np.full(len(g), record['target'])
    q = np.array([rate_kinematics(gi, yi[0], yi[1], a) for gi, yi in zip(rate, y)])
    return {'state': y, 'stress': y[:, 2]+y[:, 4], 'lambda_dot': q[:, 0],
            'plastic_rate': q[:, 2], 'nfev': nfev, 'rhs_calls':rhs_calls,
            'min_rhs_gamma_e': observed_min_ge, 'min_rhs_lambda': observed_min_lambda}


def paper_cost(ss_y, ss_pred, ys, preds, normalized=True):
    """Eq10 + Eq12 transient, or Eq11 transient alone when requested by caller.

    Division by N/K occurs OUTSIDE each square root. Sum of curve norms is
    not a pooled least-squares objective. Signed measured stresses are retained.
    """
    ss_y, ss_pred = np.asarray(ss_y), np.asarray(ss_pred)
    if ss_y.shape != ss_pred.shape or len(ys) != len(preds):
        raise ValueError('Observation/prediction groups must match.')
    if len(ss_y) and (not np.isfinite(ss_y).all() or (ss_y <= 0).any()):
        raise ValueError('Steady normalization requires positive finite observations.')
    ss = np.linalg.norm((ss_y-ss_pred)/ss_y)/len(ss_y) if len(ss_y) else 0.
    items = []
    for y, f in zip(ys, preds):
        y, f = np.asarray(y), np.asarray(f)
        scale = np.max(y) if normalized else 1.
        if scale <= 0 or y.shape != f.shape or not len(y) or not np.isfinite(y).all():
            raise ValueError('Invalid curve normalization or length.')
        items.append(float(np.linalg.norm((y-f)/scale)/len(y)))
    trans = float(np.mean(items)) if items else 0.
    return {'steady': float(ss), 'transient': trans, 'total': float(ss+trans), 'curves': items}


class Objective:
    def __init__(self, ss, records, tensor, input_mode, stage):
        self.ss, self.records = ss, records
        self.tensor, self.input_mode, self.stage = tensor, input_mode, stage
        self.calls = self.failures = 0
        self.failure_types = {}
        self.best = None
        self.started = time.monotonic()

    def __call__(self, z):
        self.calls += 1
        try:
            p = unpack(z)
            ss_pred = steady(self.ss[:, 0], p, self.tensor)
            outputs = [] if self.stage == 'scalar_steady' else [
                integrate(r, p, self.tensor, self.input_mode)['stress'] for r in self.records]
            cost = paper_cost(self.ss[:, 1], ss_pred,
                              [] if not outputs else [r['stress'] for r in self.records],
                              outputs, normalized=self.stage != 'scalar_transient')
            value = cost['transient'] if self.stage == 'scalar_transient' else cost['total']
            if not np.isfinite(value):
                raise ValueError('Nonfinite objective.')
            if self.best is None or value < self.best['value']:
                self.best = {'value': float(value), 'z': np.asarray(z).tolist(),
                             'cost_components': cost, 'parameters': asdict(p), 'call': self.calls}
            return float(value)
        except (ValueError, RuntimeError, FloatingPointError, OverflowError) as exc:
            self.failures += 1
            reason = type(exc).__name__+': '+str(exc)
            self.failure_types[reason] = self.failure_types.get(reason, 0)+1
            return np.inf  # Failed proposals are explicitly counted/rejected, not predictions.
