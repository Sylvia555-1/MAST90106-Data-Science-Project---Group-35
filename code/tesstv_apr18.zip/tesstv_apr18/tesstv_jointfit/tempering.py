"""Replica-exchange optimization with explicit temperatures and evaluation logs.

This implements parallel tempering, not an independent reconstruction of the
authors' unavailable optimizer settings. No posterior uncertainty is inferred.
"""
import time
import numpy as np
from scipy.optimize import minimize


def exchange_log_acceptance(fi, fj, ti, tj):
    return (1/ti-1/tj)*(fi-fj)


def optimize(objective, start, active, *, seed, sweeps, temperatures,
             polish_evals=1000, progress=None):
    rng = np.random.default_rng(seed)
    active = np.array(active, int)
    temperatures = np.asarray(temperatures, float)
    n = len(temperatures)
    chains = np.tile(start, (n, 1))
    chains[1:, active] = np.clip(chains[1:, active]+rng.normal(0, .08, (n-1, len(active))), 0, 1)
    values = np.array([objective(z) for z in chains])
    if not np.isfinite(values).any():
        raise RuntimeError('No valid initial replica; inspect model and bounds.')
    k = int(np.argmin(values)); best, best_value = chains[k].copy(), float(values[k])
    accepted = np.zeros(n, int); swaps = np.zeros(n-1, int)
    log = []; begun = time.monotonic()
    scales = np.geomspace(.012, .18, n)
    for sweep in range(sweeps):
        for i in range(n):
            proposal = chains[i].copy()
            # Mix coordinate moves (efficient local adjustment) and joint moves.
            moving = active if rng.random() < .25 else rng.choice(active, 1)
            proposal[moving] += rng.normal(0, scales[i], len(moving))
            if (proposal[moving] < 0).any() or (proposal[moving] > 1).any():
                continue  # symmetric random walk with hard-wall rejection
            f = objective(proposal)
            if np.isfinite(f) and (not np.isfinite(values[i]) or
                                  np.log(rng.random()) < -(f-values[i])/temperatures[i]):
                chains[i], values[i] = proposal, f; accepted[i] += 1
            if f < best_value:
                best, best_value = proposal.copy(), float(f)
        for i in range(sweep % 2, n-1, 2):
            if np.isfinite(values[i]) and np.isfinite(values[i+1]) and np.log(rng.random()) < exchange_log_acceptance(values[i], values[i+1], temperatures[i], temperatures[i+1]):
                chains[[i, i+1]] = chains[[i+1, i]]
                values[[i, i+1]] = values[[i+1, i]]; swaps[i] += 1
        if sweep % 10 == 0 or sweep == sweeps-1:
            entry = {'sweep':sweep+1, 'best':best_value, 'elapsed_s':time.monotonic()-begun,
                     'replica_costs':values.tolist()}
            log.append(entry)
            if progress:
                progress(entry)
    pt_best = best_value
    # Additional local numerical refinement; it minimizes the SAME Eq12, not SSE.
    # Explicitly reported as an implementation extension beyond published PT.
    local_count = 0
    def local(x):
        nonlocal best, best_value, local_count
        z = best.copy(); z[active] = x
        f = objective(z); local_count += 1
        if f < best_value:
            best, best_value = z.copy(), f
        if progress and local_count % 100 == 0:
            progress({'polish_evaluations':local_count, 'best':best_value,
                      'elapsed_s':time.monotonic()-begun})
        return f if np.isfinite(f) else 1e6
    result = minimize(local, best[active], method='Powell', bounds=[(0., 1.)]*len(active),
                      options={'maxfev':polish_evals, 'xtol':2e-4, 'ftol':2e-5})
    return {'z':best.tolist(), 'value':float(best_value), 'pt_best':pt_best,
            'seed':seed, 'active_indices':active.tolist(), 'temperatures':temperatures.tolist(),
            'sweeps':sweeps, 'proposal_acceptances':accepted.tolist(),
            'replica_swaps':swaps.tolist(), 'trace':log,
            'polish':{'method':'Powell on unchanged objective', 'success':bool(result.success),
                      'message':str(result.message), 'nfev':int(result.nfev)},
            'elapsed_s':time.monotonic()-begun}
