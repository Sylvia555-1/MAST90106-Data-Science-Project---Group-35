"""Run APR18 fitting, frozen-LAOS prediction and residual change detection."""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(*arguments: str) -> None:
    command = [sys.executable, *arguments]
    print("\n$ " + " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=("quick", "full"), default="quick")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--skip-fit", action="store_true",
                        help="Reuse results/fit/selected_fit.json if fitting already completed.")
    args = parser.parse_args()
    output = args.output.resolve()
    fit_dir = output / "fit"
    selected_fit = fit_dir / "selected_fit.json"

    if not args.skip_fit:
        run("fit_apr18.py", "--data", str(ROOT / "data" / "real" / "APR18.xlsx"),
            "--profile", args.profile, "--output", str(fit_dir))
    if not selected_fit.exists():
        raise FileNotFoundError(f"Missing {selected_fit}. Run without --skip-fit first.")
    run("predict_and_detect.py", "--fit", str(selected_fit),
        "--data", str(ROOT / "data" / "semisynthetic_laos"),
        "--output", str(output / "laos_change_detection"))
    print(f"\nCompleted. Open: {output / 'laos_change_detection'}")


if __name__ == "__main__":
    main()
