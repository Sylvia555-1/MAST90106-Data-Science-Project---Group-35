"""Generate report-ready APR18 t-ESSTV diagnostics without refitting.
Run: python make_report_figures.py
"""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

from fit_dataset import load_dataset, choose_unique_measured_protocols
from workbook_reader import read_step_tests
from tesstv_jointfit.core import steady, integrate
from tesstv_paper_reproduction.model import Params
PAPER_PARAMS = Params(0.0138, 0.0054, 0.029, 1.582, 0.192, 0.099, 0.0039, 1.4582, 0.2646, 0.5138)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results' / 'report_figures'
OUT.mkdir(parents=True, exist_ok=True)
DATA = ROOT / 'data' / 'real' / 'APR18.xlsx'
FIT = ROOT / 'results' / 'fit' / 'selected_fit.json'
CAL = [(0.1, 1.), (0.1, 2.5), (0.1, 5.), (5., .5), (5., 1.), (5., 2.5)]
STEADY, RECORDS, metadata = load_dataset(DATA, 'SS SAOS', 'steps', (0,1), 'original', CAL)
record_map = {(r['pre'],r['target']):r for r in RECORDS}
for test in choose_unique_measured_protocols(read_step_tests(DATA, 'steps')):
    key = (float(test.pre_rate),float(test.target_rate))
    if key not in record_map:
        frame=test.data
        t=frame['time'].to_numpy(float)
        record_map[key] = {'pre':key[0], 'target':key[1], 'time':t-t[0],
                           'rate':frame['shear_rate'].to_numpy(float),
                           'stress':frame['stress'].to_numpy(float)}
params = Params(**json.loads(FIT.read_text())['parameters'])

def metrics(y,pred):
    error = y-pred
    sst=np.sum((y-np.mean(y))**2)
    return {'n':int(len(y)), 'rmse_Pa':float(np.sqrt(np.mean(error**2))),
            'r2':float(1-np.sum(error**2)/sst) if sst>0 else None}

# Figure 1: steady state, using identical 16 measured points as fitting.
rates, obs = STEADY[:,0],STEADY[:,1]
pred=steady(rates,params,tensor=True)
curve_rates=np.geomspace(min(rates),max(rates),240)
curve_pred=steady(curve_rates,params,tensor=True)
fig,ax=plt.subplots(figsize=(7,4.5))
ax.scatter(rates,obs,s=35,label='APR18 measurements',zorder=3)
ax.plot(curve_rates,curve_pred,label='Fitted t-ESSTV')
ax.set(xlabel=r'Shear rate (s$^{-1}$)',ylabel='Shear stress (Pa)',title='APR18 steady-state calibration')
ax.set_xscale('log');ax.set_yscale('log');ax.grid(alpha=.25,which='both');ax.legend()
fig.tight_layout();fig.savefig(OUT/'steady_state_fit.png',dpi=220);plt.close(fig)
results={'steady_state':metrics(obs,pred),'protocols':{}}

# Figure 2 and 3: separate step calibration from a held-out test.
calib=sorted(CAL)
held=sorted(set(record_map)-set(CAL))
print('Held-out:',held)
for group,name in [(calib,'step_calibration'),(held,'step_held_out')]:
    if not group: continue
    cols=3 if len(group)>2 else 1
    rows=int(np.ceil(len(group)/cols))
    fig,axes=plt.subplots(rows,cols,figsize=(5*cols,3.4*rows),squeeze=False)
    for ax,key in zip(axes.flat,group):
        r=record_map[key]
        print('Predicting:',key,'n=',len(r['time']),flush=True)
        try:
            res=integrate(r,params,tensor=True,input_mode='measured',tight=True,method='Radau')
            prediction=res['stress']
            quality=metrics(r['stress'],prediction)
            results['protocols'][f'{key[0]:g}->{key[1]:g}']={**quality,'group':'calibration' if name=='step_calibration' else 'held_out'}
            ax.plot(r['time'],r['stress'],label='Measured',lw=1.25)
            ax.plot(r['time'],prediction,label='t-ESSTV',lw=1.2)
            ax.set_title(f'{key[0]:g} → {key[1]:g} s⁻¹ | RMSE={quality["rmse_Pa"]:.4g} Pa, R²={quality["r2"]:.3f}',fontsize=10)
        except Exception as exc:
            results['protocols'][f'{key[0]:g}->{key[1]:g}']={'group':name,'error':str(exc)}
            ax.text(.05,.5,'Prediction failed: '+str(exc)[:65],transform=ax.transAxes,wrap=True)
        ax.set_xlabel('Time after step (s)');ax.set_ylabel('Stress (Pa)');ax.grid(alpha=.25)
    for ax in list(axes.flat)[len(group):]: ax.axis('off')
    axes.flat[0].legend(loc='best',fontsize=8)
    fig.tight_layout();fig.savefig(OUT/(name+'.png'),dpi=200);plt.close(fig)

# Table comparison with published Donor 5 values, not a 'reproduction accuracy' metric.
fields=[('mu0_c','Pa s'),('muinf_c','Pa s'),('tau_c','s'),('tau_break','s'),('tau_aggr','s'),('mu_r','Pa s'),('sigma_y0','Pa'),('tau_lambda','s'),('G_r','Pa'),('G_c','Pa')]
lines=['Parameter | Units | Armstrong et al. (2022) Donor 5 | Our fitted APR18']
lines.append('--- | --- | ---: | ---:')
for field,unit in fields:
    lines.append(f'{field} | {unit} | {getattr(PAPER_PARAMS,field):.6g} | {getattr(params,field):.6g}')
(OUT/'paper_vs_our_parameters.md').write_text('\n'.join(lines)+'\n')
(OUT/'evaluation_metrics.json').write_text(json.dumps(results,indent=2)+'\n')
print('\nSteady metrics:',results['steady_state'])
for k,v in results['protocols'].items(): print(k,v)
print('\nSaved in:',OUT)
