"""Fit dataset-specific t-ESSTV parameters from a rheology workbook.

The fitting sequence follows the joint t-ESSTV implementation:
scalar steady state -> scalar transient -> tensorial joint fit.  Calibration
protocols are explicit and are never selected from evaluation performance.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

import numpy as np

import workbook_reader as workbook_io
from tesstv_jointfit.core import (
    BOUNDS,
    NAMES,
    Objective,
    PUBLISHED_MEAN,
    pack,
    unpack,
)
from tesstv_jointfit.tempering import optimize


DEFAULT_CALIBRATION = "0.1:1,0.1:2.5,0.1:5,5:0.1,5:1,5:2.5"


def choose_unique_measured_protocols(tests):
    """Choose one audited record for each measured pre/target pair."""
    groups = {}
    for test in tests:
        key = (float(test.pre_rate), float(test.target_rate))
        groups.setdefault(key, []).append(test)
    selected = []
    for key in sorted(groups):
        candidates = groups[key]
        selected.append(
            max(
                candidates,
                key=lambda item: (not bool(item.protocol_warning), len(item.data)),
            )
        )
    return selected


def parse_protocols(value: str) -> list[tuple[float, float]]:
    result: list[tuple[float, float]] = []
    for item in value.split(","):
        left, right = item.strip().split(":", 1)
        result.append((float(left), float(right)))
    if len(set(result)) != len(result):
        raise ValueError("Calibration protocols must be unique.")
    return result


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def load_dataset(
    workbook: Path,
    ss_sheet: str | None,
    step_sheet: str | None,
    ss_cols: tuple[int, int],
    ss_block: str,
    calibration: list[tuple[float, float]],
) -> tuple[np.ndarray, list[dict[str, object]], dict[str, object]]:
    blocks = workbook_io.read_steady_state_blocks(workbook, ss_sheet, ss_cols)
    active_name, steady_frame = workbook_io.choose_steady_state_block(blocks, ss_block)
    all_tests = workbook_io.read_step_tests(workbook, step_sheet)
    unique = choose_unique_measured_protocols(all_tests)
    mapping = {(float(t.pre_rate), float(t.target_rate)): t for t in unique}
    missing = [key for key in calibration if key not in mapping]
    if missing:
        available = ", ".join(f"{a:g}:{b:g}" for a, b in sorted(mapping))
        wanted = ", ".join(f"{a:g}:{b:g}" for a, b in missing)
        raise ValueError(
            f"Missing calibration protocols: {wanted}. Available measured protocols: {available}. "
            "Choose explicit alternatives; the code will not invent a protocol."
        )

    records: list[dict[str, object]] = []
    for key in calibration:
        test = mapping[key]
        frame = test.data
        recorded_time = frame["time"].to_numpy(float)
        records.append(
            {
                "id": f"{key[0]:g}_to_{key[1]:g}".replace(".", "p"),
                "pre": key[0],
                "target": key[1],
                "title": test.title,
                "source_column": int(test.source_column),
                "time": recorded_time - recorded_time[0],
                "recorded_time": recorded_time,
                "stress": frame["stress"].to_numpy(float),
                "rate": frame["shear_rate"].to_numpy(float),
            }
        )

    steady = steady_frame[["shear_rate", "stress"]].to_numpy(float)
    if not np.isfinite(steady).all() or (steady <= 0).any():
        raise ValueError("Steady-state calibration data must be positive and finite.")
    digest = hashlib.sha256(workbook.read_bytes()).hexdigest()
    metadata = {
        "workbook": str(workbook),
        "sha256": digest,
        "steady_block": active_name,
        "steady_points": len(steady),
        "calibration_protocols": [[a, b] for a, b in calibration],
        "calibration_records": [
            {
                "protocol": [float(record["pre"]), float(record["target"])],
                "source_column_zero_based": int(record["source_column"]),
                "title": str(record["title"]),
            }
            for record in records
        ],
        "held_out_protocols": [[a, b] for a, b in sorted(set(mapping) - set(calibration))],
    }
    return steady, records, metadata


PROFILES = {
    "quick": {
        "steady": (20, 80),
        "transient": (8, 50),
        "joint": (12, 100),
        "seeds": (11,),
        "replicas": 4,
    },
    "full": {
        "steady": (600, 1800),
        "transient": (160, 900),
        "joint": (240, 2400),
        "seeds": (11, 29),
        "replicas": 8,
    },
}


def fit(
    steady: np.ndarray,
    records: list[dict[str, object]],
    output: Path,
    metadata: dict[str, object],
    profile_name: str,
) -> Path:
    profile = PROFILES[profile_name]
    output.mkdir(parents=True, exist_ok=True)
    manifest = {
        **metadata,
        "profile": profile_name,
        "profile_warning": "quick is for code checking only, not final scientific results"
        if profile_name == "quick"
        else None,
        "variable_parameters": list(NAMES),
        "fixed_parameters": {"gamma0_r": 1.0, "d": 0.5, "m": 1.5},
        "bounds": BOUNDS.tolist(),
        "objective": "Eq10 scalar steady -> Eq11 scalar transient -> Eq12 tensor joint",
        "input_mode": "measured piecewise-linear shear-rate history",
        "started": time.strftime("%Y-%m-%d %H:%M:%S %z"),
    }
    save_json(output / "manifest.json", manifest)

    def stage(
        name: str,
        start: np.ndarray,
        tensor: bool,
        active: range,
        objective_stage: str,
        seed: int,
        sweeps: int,
        polish: int,
        tmin: float,
        tmax: float,
    ) -> dict[str, object]:
        checkpoint = output / f"{name}.json"
        if checkpoint.exists():
            return json.loads(checkpoint.read_text())
        objective = Objective(steady, records, tensor, "measured", objective_stage)
        result = optimize(
            objective,
            start,
            active,
            seed=seed,
            sweeps=sweeps,
            temperatures=np.geomspace(tmin, tmax, int(profile["replicas"])),
            polish_evals=polish,
        )
        result.update(
            {
                "parameters": asdict(unpack(result["z"])),
                "objective_calls": objective.calls,
                "failed_proposals": objective.failures,
                "failure_types": objective.failure_types,
                "objective_stage": objective_stage,
            }
        )
        save_json(checkpoint, result)
        return result

    steady_sweeps, steady_polish = profile["steady"]
    transient_sweeps, transient_polish = profile["transient"]
    joint_sweeps, joint_polish = profile["joint"]
    scalar_steady = stage(
        "scalar_steady", pack(PUBLISHED_MEAN), False, range(7), "scalar_steady",
        11, steady_sweeps, steady_polish, 2e-5, 0.05,
    )
    scalar_transient = stage(
        "scalar_transient", np.asarray(scalar_steady["z"]), False, range(7, 10),
        "scalar_transient", 11, transient_sweeps, transient_polish, 2e-7, 0.001,
    )
    candidates = []
    for seed in profile["seeds"]:
        candidates.append(
            stage(
                f"tensor_joint_seed{seed}", np.asarray(scalar_transient["z"]), True,
                range(10), "tensor_joint", int(seed), joint_sweeps, joint_polish,
                1e-5, 0.03,
            )
        )
    best = min(candidates, key=lambda item: float(item["value"]))
    selected = {
        "selection": "smallest calibration Eq12 objective; held-out protocols not used",
        "profile": profile_name,
        "seed": best["seed"],
        "z": best["z"],
        "parameters": best["parameters"],
        "value": best["value"],
        "candidate_values": {str(item["seed"]): item["value"] for item in candidates},
        "calibration_protocols": metadata["calibration_protocols"],
        "calibration_records": metadata["calibration_records"],
        "held_out_protocols": metadata["held_out_protocols"],
    }
    selected_path = output / "selected_fit.json"
    save_json(selected_path, selected)
    return selected_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ss-sheet")
    parser.add_argument("--step-sheet")
    parser.add_argument("--ss-cols", default="0,1", help="Zero-based shear-rate,stress columns")
    parser.add_argument("--ss-block", default="auto")
    parser.add_argument("--calibration-protocols", default=DEFAULT_CALIBRATION)
    parser.add_argument("--profile", choices=tuple(PROFILES), default="full")
    args = parser.parse_args()
    cols = tuple(int(value) for value in args.ss_cols.split(","))
    if len(cols) != 2:
        raise ValueError("--ss-cols requires two zero-based column indices.")
    protocols = parse_protocols(args.calibration_protocols)
    steady, records, metadata = load_dataset(
        args.data.resolve(), args.ss_sheet, args.step_sheet, cols, args.ss_block, protocols
    )
    result = fit(steady, records, args.output.resolve(), metadata, args.profile)
    print(f"Saved fitted parameters: {result}")


if __name__ == "__main__":
    main()
