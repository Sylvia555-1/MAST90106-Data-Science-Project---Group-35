"""Fit a dataset-specific t-ESSTV parameter vector to APR18 steady/Step data."""
from __future__ import annotations

import argparse
from pathlib import Path

from fit_dataset import fit, load_dataset


ROOT = Path(__file__).resolve().parent
APR18_PROTOCOLS = [
    (0.1, 1.0),
    (0.1, 2.5),
    (0.1, 5.0),
    (5.0, 0.5),
    (5.0, 1.0),
    (5.0, 2.5),
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "real" / "APR18.xlsx")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profile", choices=("quick", "full"), default="full")
    args = parser.parse_args()
    steady, records, metadata = load_dataset(
        args.data.resolve(),
        "SS SAOS",
        "steps",
        (0, 1),
        "original",
        APR18_PROTOCOLS,
    )
    selected = fit(steady, records, args.output, metadata, args.profile)
    print(f"APR18 fitted parameters: {selected}")


if __name__ == "__main__":
    main()
