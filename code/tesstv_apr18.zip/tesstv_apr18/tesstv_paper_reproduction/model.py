"""Audited positive-simple-shear t-ESSTV core, adapted from the user's v3 script.

Source: ~/Desktop/tensorial_esstv_figure5_v3.py, model_rhs and auxiliaries;
Armstrong et al. (2022), doi:10.3389/fphy.2022.889065 Tables 1-3;
Pincot et al. (2023), doi:10.1063/5.0169051 Eqs. 6-15 and Table I.

This implements the PRINTED absolute-difference rouleaux term. Its shear
reflection symmetry is unresolved; negative rates are deliberately rejected.
See EQUATIONS.md. No state clipping or silent failed-solver fallback.
Positive-flow implementation copied from the independently tested demo_v2
core, then re-audited against the paper for this fixed-parameter reproduction.
State order matches the supplied v3: lambda, gamma_e, Cxy, Cxx, Rxy, Rxx, Ryy, Rzz.
All times are seconds, shear rates s^-1, stresses/moduli Pa, viscosities Pa s.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq


MODEL_VERSION = "printed-tESSTV-positive-simple-shear-v1"
STATE_NAMES = ("lambda", "gamma_e", "sigma_c_xy", "sigma_c_xx",
               "sigma_r_xy", "sigma_r_xx", "sigma_r_yy", "sigma_r_zz")


@dataclass(frozen=True)
class Params:
    mu0_c: float
    muinf_c: float
    tau_c: float
    tau_break: float
    tau_aggr: float
    mu_r: float
    sigma_y0: float
    tau_lambda: float
    G_r: float
    G_c: float
    gamma0_r: float = 1.0
    d: float = 0.5
    m: float = 1.5

    def __post_init__(self):
        values = asdict(self)
        if not all(np.isfinite(v) for v in values.values()):
            raise ValueError("Every model parameter must be finite.")
        if any(v <= 0 for k, v in values.items()
               if k not in ("sigma_y0", "tau_aggr", "tau_break", "tau_c")):
            raise ValueError("Viscosities, moduli, timescale and exponents must be positive.")
        if min(self.sigma_y0, self.tau_aggr, self.tau_break, self.tau_c) < 0:
            raise ValueError("Yield stress and kinetic/Cross coefficients cannot be negative.")
        if self.mu0_c < self.muinf_c:
            raise ValueError("This shear-thinning model requires mu0_c >= muinf_c.")


def published_donor5() -> Params:
    """Frontiers 2022 Tables 6/7 Donor 5 / APR18, printed precision."""
    return Params(.0138, .0054, .029, 1.582, .192, .099, .0039,
                  1.4582, .2646, .5138)


def lambda_ss(plastic_rate, p: Params):
    """Exact structure equilibrium at prescribed constant plastic rate."""
    q = np.abs(np.asarray(plastic_rate, dtype=float))
    a = 1 + (p.tau_aggr * q)**p.d
    return a / (a + p.tau_break * q)


def lambda_dot(plastic_rate, lam, p: Params):
    q = np.abs(np.asarray(plastic_rate, dtype=float))
    return ((1 - np.asarray(lam)) * (1 + (p.tau_aggr * q)**p.d)
            - p.tau_break * q * np.asarray(lam)) / p.tau_lambda


def lambda_exact(time, initial_lambda: float, plastic_rate: float, p: Params):
    """Analytical solution for fixed q; time means elapsed time from initial_lambda."""
    q = abs(plastic_rate)
    k = (1 + (p.tau_aggr*q)**p.d + p.tau_break*q) / p.tau_lambda
    eq = lambda_ss(q, p)
    return eq + (initial_lambda - eq) * np.exp(-k*np.asarray(time))


def eta_cross(rate, p: Params):
    return p.muinf_c + (p.mu0_c-p.muinf_c)/(1+p.tau_c*np.abs(rate))


def eta_c_from_sigma_xx(sigma_c_xx: float, p: Params) -> float:
    if not np.isfinite(sigma_c_xx) or sigma_c_xx < 0:
        raise ValueError("Cxx must be nonnegative; invalid state cannot be clipped.")
    b = p.tau_c * np.sqrt(p.G_c*sigma_c_xx/2) - p.mu0_c
    c = -p.muinf_c * p.tau_c * np.sqrt(p.G_c*sigma_c_xx/2)
    disc = np.sqrt(b*b-4*c)
    # Stable quadratic root; avoids cancellation for large positive b.
    return float((-b+disc)/2 if b <= 0 else (-2*c)/(b+disc))


def equivalent_rouleaux_stress(xx, yy, zz, xy):
    mean = (xx+yy+zz)/3
    return float(np.sqrt(((xx-mean)**2+(yy-mean)**2+(zz-mean)**2)/2+xy**2))


def structure_kinematics(rate: float, lam: float, gamma_e: float, p: Params):
    """Printed auxiliary equations; no truncation of lambda or elastic strain."""
    if rate < 0:
        raise NotImplementedError("Negative-rate / LAOS validation is blocked; see EQUATIONS.md.")
    if not np.isfinite(rate) or not np.isfinite(lam) or lam <= 0:
        raise ValueError("Finite nonnegative rate and strictly positive lambda required.")
    ratio = gamma_e/(p.gamma0_r*lam)
    if 2-ratio <= 0:
        raise ValueError("Plastic-rate denominator is nonpositive; invalid state.")
    q = rate/(2-ratio)
    dl = float(lambda_dot(q, lam, p))
    de = q - ratio*abs(q) + ratio*p.gamma0_r*min(dl, 0.)
    return dl, de, q


def rhs(time: float, state: np.ndarray, rate: float, p: Params):
    lam, ge, cxy, cxx, rxy, rxx, ryy, rzz = state
    dl, de, _ = structure_kinematics(rate, lam, ge, p)
    eta = eta_c_from_sigma_xx(cxx, p)
    eq = equivalent_rouleaux_stress(rxx, ryy, rzz, rxy)
    back = p.sigma_y0*ge/p.gamma0_r
    if eq == 0:
        if back != 0:
            raise ValueError("Zero rouleaux stress with nonzero back stress is singular.")
        relaxation = 0.  # Product with the exactly zero stress tensor is zero.
    else:
        relaxation = p.G_r * abs(eq-back) / (p.mu_r*lam**(p.m-1)*eq)
    return np.array([dl, de, p.G_c*(rate-cxy/eta),
                     2*rate*cxy-p.G_c*cxx/eta,
                     (ryy+lam*p.G_r)*rate-relaxation*rxy,
                     2*rate*rxy-relaxation*rxx,
                     -relaxation*ryy, -relaxation*rzz])


def equilibrium_state(rate: float, p: Params):
    """Exact positive-flow stationary solution of the tensor ODE.

    This represents an INFINITELY LONG constant-rate prehistory assumption.
    Tensorial normal stresses reduce the yield contribution; the non-tensorial
    scalar stress expression printed in the review is NOT an exact substitute.
    At zero rate, choose the fully rebuilt stress-free equilibrium.
    """
    if not np.isfinite(rate) or rate < 0:
        raise ValueError("equilibrium_state requires finite nonnegative shear rate.")
    if rate == 0:
        return np.array([1., 0., 0., 0., 0., 0., 0., 0.])
    lam = float(lambda_ss(rate, p))
    ge = p.gamma0_r*lam
    eta = float(eta_cross(rate, p))
    a, b = p.mu_r*lam**p.m*rate, p.sigma_y0*lam
    # Rxx=2*Rxy^2/(lambda*Gr), hence sigma_eq=Rxy*sqrt(1+4*Rxy^2/(3*(lambda*Gr)^2)).
    f = lambda s: s-a-b/np.sqrt(1+4*s*s/(3*(lam*p.G_r)**2))
    rxy = a if b == 0 else brentq(f, a, a+b, xtol=5e-16, rtol=1e-14)
    y = np.array([lam, ge, eta*rate, 2*(eta*rate)**2/p.G_c,
                  rxy, 2*rxy*rxy/(lam*p.G_r), 0., 0.])
    if np.max(np.abs(rhs(0., y, rate, p))) > 1e-7:
        raise RuntimeError("Tensorial equilibrium did not satisfy the ODE.")
    return y


def steady_state_stress(rate, p: Params):
    arr = np.asarray(rate, dtype=float)
    stresses = []
    for g in arr.ravel():
        y = equilibrium_state(float(g), p)
        stresses.append(y[2]+y[4])
    result = np.array(stresses).reshape(arr.shape)
    return float(result) if arr.ndim == 0 else result


def validate_state(states, tolerance=2e-6):
    y = np.asarray(states)
    y = y[None, :] if y.ndim == 1 else y
    if y.ndim != 2 or y.shape[1] != 8 or not np.all(np.isfinite(y)):
        raise ValueError("State must have eight finite components.")
    if np.any(y[:, 0] <= 0) or np.any(y[:, 0] > 1+tolerance):
        raise ValueError("lambda left (0,1] beyond solver tolerance.")
    if np.any(y[:, 3] < 0):
        raise ValueError("Cxx left its nonnegative domain.")


def simulate(time, rate_fn: Callable[[float], float], p: Params, *,
             initial_state, breakpoints=(), rtol=2e-8, atol=1e-10,
             max_step=.1, method="BDF"):
    """Integrate known input history; caller MUST provide initial state.

    Input is right-continuous. Explicit breakpoints split discontinuities;
    no solver step straddles an unannounced rate jump. Output state is N x 8.
    """
    t = np.asarray(time, dtype=float)
    if t.ndim != 1 or len(t) < 2 or not np.all(np.isfinite(t)) or np.any(np.diff(t) <= 0):
        raise ValueError("time must be a finite strictly increasing vector.")
    if min(rtol, atol, max_step) <= 0:
        raise ValueError("Solver tolerances and max_step must be positive.")
    state = np.asarray(initial_state, dtype=float).copy()
    validate_state(state)
    bounds = np.unique(np.r_[t[0], list(breakpoints), t[-1]])
    if bounds[0] != t[0] or bounds[-1] != t[-1]:
        raise ValueError("breakpoints must lie within the requested time span.")
    result = np.empty((len(t), 8))
    result[0] = state
    nfev = 0
    solver_methods = []
    for left, right in zip(bounds[:-1], bounds[1:]):
        idx = np.flatnonzero((t > left) & (t <= right))
        eval_time = np.unique(np.r_[t[idx], right])
        # At a jump endpoint use the preceding input's left limit. Subsequent
        # segment starts at right with its own right-continuous forcing.
        def fun(x, y):
            gx = np.nextafter(right, left) if x >= right else x
            return rhs(x, y, float(rate_fn(gx)), p)
        # At stress-free rest an implicit solver's numerical Jacobian perturbs
        # gamma_e independently of the zero R tensor, creating a singular,
        # incompatible trial state. Use explicit integration for this segment;
        # this follows the same ODE and does not perturb or clip initial data.
        at_rest_boundary = np.all(state[4:] == 0) and state[1] == 0
        segment_method = "RK45" if at_rest_boundary and method in ("BDF", "Radau") else method
        sol = solve_ivp(fun, (left, right), state, t_eval=eval_time,
                        method=segment_method, rtol=rtol, atol=atol, max_step=max_step)
        solver_methods.append(segment_method)
        if not sol.success or sol.y.shape[1] != len(eval_time):
            raise RuntimeError(f"t-ESSTV solver failed: {sol.message}")
        validate_state(sol.y.T)
        result[idx] = sol.y[:, np.searchsorted(eval_time, t[idx])].T
        state = sol.y[:, -1]
        nfev += sol.nfev
    rate = np.array([rate_fn(float(x)) for x in t])
    diagnostics = np.array([structure_kinematics(g, y[0], y[1], p)
                            for g, y in zip(rate, result)])
    if np.any(result[:, 1]/(p.gamma0_r*result[:, 0]) > 1+2e-5):
        raise RuntimeError("Elastic strain exceeded gamma_max; result not clipped.")
    return {"time": t, "sigma": result[:, 2]+result[:, 4],
            "lambda": result[:, 0], "lambda_dot": diagnostics[:, 0],
            "gamma_e": result[:, 1], "gdot": rate,
            "gdot_p": diagnostics[:, 2], "state": result, "nfev": nfev,
            "solver_methods": solver_methods}


def simulate_steps(time, rates, jump_times, p: Params, *, pre_rate=None,
                   initial_state=None, **solver_options):
    """Positive piecewise-constant history with explicit prehistory choice.

    len(rates)=len(jump_times)+1; initial_rate applies at time[0]. Supply
    initial_state for a finite prehistory or pre_rate for steady prehistory.
    """
    rates = np.asarray(rates, dtype=float)
    jumps = np.asarray(jump_times, dtype=float)
    if rates.ndim != 1 or len(rates) != len(jumps)+1 or np.any(np.diff(jumps) <= 0):
        raise ValueError("Require ordered jump_times and one extra rate.")
    if not np.all(np.isfinite(rates)) or np.any(rates < 0):
        raise ValueError("Only finite nonnegative rate histories are validated.")
    if (pre_rate is None) == (initial_state is None):
        raise ValueError("Supply exactly one of pre_rate or initial_state.")
    y0 = equilibrium_state(pre_rate, p) if initial_state is None else initial_state
    rate_fn = lambda x: float(rates[np.searchsorted(jumps, x, side="right")])
    return simulate(time, rate_fn, p, initial_state=y0, breakpoints=jumps, **solver_options)
