"""Predict APR18-based LAOS cases with frozen APR18 t-ESSTV parameters.

The detection threshold is calibrated from the no-change control only and is
then frozen before it is applied to the 10%, 20% and 30% change cases.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from tesstv_jointfit.core import integrate, unpack


ROOT = Path(__file__).resolve().parent
CASES = ("control", "change_10pct", "change_20pct", "change_30pct")


def load_case(path: Path) -> tuple[dict, pd.DataFrame]:
    frame = pd.read_csv(path)
    required = {"time_s", "strain", "shear_rate_1_s", "stress_Pa"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"{path} is missing columns: {sorted(missing)}")
    time_recorded = frame["time_s"].to_numpy(float)
    time = time_recorded - time_recorded[0]
    rate = frame["shear_rate_1_s"].to_numpy(float)
    record = {
        "time": time,
        "recorded_time": time_recorded,
        "rate": rate,
        "stress": frame["stress_Pa"].to_numpy(float),
        "strain": frame["strain"].to_numpy(float),
        "pre": max(float(rate[0]), 1e-6),
        "target": float(rate[-1]),
    }
    return record, frame


def rolling_rmse(residual: np.ndarray, samples: int) -> np.ndarray:
    return pd.Series(residual**2).rolling(samples, min_periods=samples).mean().pow(0.5).to_numpy()


def first_persistent_alarm(time: np.ndarray, values: np.ndarray, threshold: float,
                           onset: float | None, persistence: int) -> tuple[float | None, int]:
    valid = np.isfinite(values)
    above = valid & (values > threshold)
    run = 0
    detected = None
    for index, flag in enumerate(above):
        run = run + 1 if flag else 0
        if run >= persistence:
            detected = float(time[index - persistence + 1])
            break
    false_alarms = 0 if onset is None else int(np.sum(above & (time < onset)))
    return detected, false_alarms


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fit", type=Path, required=True)
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "semisynthetic_laos")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--window-s", type=float, default=2.0)
    parser.add_argument("--persistence-s", type=float, default=0.5)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    figures = args.output / "figures"
    figures.mkdir(exist_ok=True)

    payload = json.loads(args.fit.read_text())
    parameters = unpack(np.asarray(payload["z"], float))
    metadata = json.loads((args.data / "metadata.json").read_text())
    truth = {item["case"]: item["ground_truth_onset_s"] for item in metadata["cases"]}

    predictions: dict[str, pd.DataFrame] = {}
    metric_rows = []
    for case in CASES:
        record, _ = load_case(args.data / "observable" / f"{case}.csv")
        result = integrate(
            record, parameters, tensor=True, input_mode="measured",
            max_rhs_calls=2_000_000, input_step_fraction=1.0,
        )
        observed = record["stress"]
        predicted = np.asarray(result["stress"])
        residual = observed - predicted
        dt = float(np.median(np.diff(record["recorded_time"])))
        window_n = max(2, int(round(args.window_s / dt)))
        rmse = rolling_rmse(residual, window_n)
        output = pd.DataFrame({
            "time_s": record["recorded_time"],
            "strain": record["strain"],
            "shear_rate_1_s": record["rate"],
            "stress_observed_Pa": observed,
            "stress_tesstv_predicted_Pa": predicted,
            "residual_Pa": residual,
            "rolling_rmse_Pa": rmse,
            "lambda_tesstv_predicted": result["state"][:, 0],
        })
        output.to_csv(args.output / f"{case}_prediction.csv", index=False)
        predictions[case] = output
        metric_rows.append({
            "case": case,
            "ground_truth_onset_s": truth[case],
            "overall_rmse_Pa": float(np.sqrt(np.mean(residual**2))),
            "overall_mae_Pa": float(np.mean(np.abs(residual))),
        })

    control_rmse = predictions["control"]["rolling_rmse_Pa"].to_numpy(float)
    finite_control = control_rmse[np.isfinite(control_rmse)]
    median = float(np.median(finite_control))
    mad = float(np.median(np.abs(finite_control - median)))
    threshold = float(np.max(finite_control) + 3.0 * 1.4826 * mad)

    detection_rows = []
    for row in metric_rows:
        case = row["case"]
        frame = predictions[case]
        time = frame["time_s"].to_numpy(float)
        values = frame["rolling_rmse_Pa"].to_numpy(float)
        dt = float(np.median(np.diff(time)))
        persistence_n = max(1, int(round(args.persistence_s / dt)))
        onset = truth[case]
        detected, false_alarms = first_persistent_alarm(
            time, values, threshold, onset, persistence_n
        )
        if onset is None:
            false_alarms = int(np.sum(np.isfinite(values) & (values > threshold)))
        detection_rows.append({
            **row,
            "rolling_window_s": args.window_s,
            "control_only_threshold_Pa": threshold,
            "detected_onset_s": detected,
            "detection_delay_s": None if onset is None or detected is None else detected - float(onset),
            "false_alarm_samples_before_onset": false_alarms,
        })
    pd.DataFrame(detection_rows).to_csv(args.output / "detection_summary.csv", index=False)

    fig, axes = plt.subplots(4, 1, figsize=(13, 11), sharex=True)
    for ax, case in zip(axes, CASES):
        frame = predictions[case]
        ax.plot(frame["time_s"], frame["stress_observed_Pa"], lw=1.0, label="Observed")
        ax.plot(frame["time_s"], frame["stress_tesstv_predicted_Pa"], lw=1.0,
                label="Frozen t-ESSTV prediction")
        if truth[case] is not None:
            ax.axvline(truth[case], color="black", ls="--", lw=1.0, label="Injected onset")
        ax.set_title(case)
        ax.set_ylabel("Stress (Pa)")
        ax.grid(alpha=0.25)
    axes[0].legend(ncol=3, fontsize=9)
    axes[-1].set_xlabel("Time (s)")
    fig.tight_layout()
    fig.savefig(figures / "stress_observed_vs_tesstv.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(4, 1, figsize=(13, 11), sharex=True)
    for ax, case in zip(axes, CASES):
        frame = predictions[case]
        ax.plot(frame["time_s"], frame["rolling_rmse_Pa"], lw=1.2, label="Rolling RMSE")
        ax.axhline(threshold, color="tab:red", ls="--", lw=1.0, label="Control-only threshold")
        if truth[case] is not None:
            ax.axvline(truth[case], color="black", ls="--", lw=1.0, label="Injected onset")
        ax.set_title(case)
        ax.set_ylabel("RMSE (Pa)")
        ax.grid(alpha=0.25)
    axes[0].legend(ncol=3, fontsize=9)
    axes[-1].set_xlabel("Time (s)")
    fig.tight_layout()
    fig.savefig(figures / "rolling_rmse_and_detection.png", dpi=180)
    plt.close(fig)

    print(f"Saved predictions, detection summary and figures to: {args.output}")


if __name__ == "__main__":
    main()
