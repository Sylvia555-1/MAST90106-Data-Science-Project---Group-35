# Start here: APR18 Fourier analysis client handover

## Apply this update to your existing project

Replace only STFT_FFT_ON_APR18.ipynb in your actual project root, beside APR18.xlsx. Keep FFT_synthetic.ipynb, STFT_synthetic.ipynb, metadata.json, observable/ and truth/ in their existing locations. Those synthetic-data files are not read by this notebook.

This archive includes an unchanged copy of the uploaded APR18.xlsx and the verified revised outputs. You do not need to replace your existing identical workbook. To run the archive independently, extract it, open its notebook in Jupyter and use Restart Kernel and Run All.

DATA_DIR = Path(".") assumes Jupyter's working directory is the project root. Otherwise set DATA_DIR explicitly. All scientific settings are grouped in Setup. Results go to DATA_DIR/results in timestamped folders. Each complete rerun recalibrates references; do not reuse old references after changing windows/features.

Python with NumPy, pandas, Matplotlib, IPython and openpyxl is required. requirements.txt records the dependency versions used for verification; Jupyter itself is additionally needed for interactive notebook use.

## Three stages, distinct evidence

1. Blocks 1-12: original measured APR18 LAOS records. Confirmed reference departures are exploratory, with no verified original event-time labels. Feature changes, sign, effect size and reference sensitivity are descriptive.
2. Blocks 13-17: controlled additions to each original record. Gain fraction scales stress; third-harmonic/noise fractions scale added RMS relative to pre-onset centred stress RMS. Paired responses compare modified and original features at the same observation window.
3. Blocks 18-21: compare exploratory confirmations against the unchanged original background and inspect parameter sensitivity. Pre-injection alarms are not evaluated in this supplementary monitoring protocol. Conditional confirmation lag does not alone prove successful detection of the injection.

This notebook's supplementary perturbations are different from the separate synthetic benchmark used by the FFT_synthetic and STFT_synthetic notebooks.

## Main improvements

- Retained the original 21 Block numbers and original calculation functions, with English stage/purpose/interpretation notes.
- Centralised paths and scientific settings; no uploaded-number filename alternatives.
- Added report feature views, reference-sensitivity maps, median/IQR noise response plots, noise alarm counts with repeat denominators, paired alarm-category summaries and parameter-sensitivity summaries.
- Retained complete eight-feature figures, raw tables and individual alarm events.
- Corrected feature_medians.csv to include the case identifier, which was previously lost during index=False export; original numeric medians are unchanged.
- Added PDF as well as PNG exports for supplementary figures, readable first-alarm states, output indexes, field dictionaries, captions, environment records and checksums.
- Removed fixed observed-result statements from original-data interpretation notes in favour of actual exported results and current settings.

## Read the outputs

Stage A has features/, input_quality/, scores/ and figures/ subfolders. Stage B exports complete feature-response data. Its alarm_evaluation_* subfolder contains Stage C outputs. Each stage includes README_results.md and result_index.csv; use these first, then data_dictionary.csv. Report candidates begin with report_. PDFs are preferred for report insertion, PNGs for quick viewing.

ND means no confirmed departure in the available monitoring interval; UNDEF/U means reference scale was undefined. Numeric CSV fields remain missing where a numeric result is unavailable. Multiple confirmed events are retained; summary first-alarm times are not event counts.

A large robust score can accompany a small physical percentage change. The first complete window is a plotting origin only. Default references use windows ending by 20 s and monitoring uses later window ends, permitting observation-window overlap with the reference time interval. Block 8's disjoint-time candidate coverage is a diagnostic alternative, not the final rule.

Noise seed medians/IQRs and n/N counts describe simulations sharing measured backgrounds, not donor uncertainty or independent clinical performance. Post-burst exact recovery follows from unchanged samples and finite window support. Neither no alarm nor several related-feature alarms proves absence/presence of a physical material event.

## Verification

Original and revised code cells were executed in order on the exact uploaded workbook. All original calculation function bodies are unchanged. Exact comparisons passed for 717 original tables/collections, including window features, input diagnostics, scores, raw response metrics and alarm outputs. The sole intentional schema correction is the added case identifier in the median export. Notebook output cells contain actual workbook results, not fixtures. See verification_summary.json.
