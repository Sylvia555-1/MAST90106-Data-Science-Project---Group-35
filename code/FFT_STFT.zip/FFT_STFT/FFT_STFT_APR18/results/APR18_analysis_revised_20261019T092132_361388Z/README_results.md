# Client results guide

Stage A: original APR18 LAOS records; exploratory reference departures, no labelled material-change onset.

Read result_index.csv for all generated files and data_dictionary.csv for fields. PDF/PNG pairs contain the same figure; PDF is preferred for reports.
Numeric CSV fields retain missing values. ND in readable alarm tables means no confirmed reference departure in the monitoring interval; UNDEF means reference scores were undefined.
Original APR18 has no verified event labels: confirmations are reference departures, not validated material change or clotting times. Large robust scores can accompany tiny relative changes.
References are based on complete windows ending by the reference endpoint. Main monitoring uses outputs ending after that endpoint, and windows may overlap the reference time interval. Block 8 tests a stricter disjoint-interval alternative for coverage only.
Seeded noise versions share the same measured background. Counts and median/IQR summaries describe these simulations, not independent donor performance. Confirmation lags include alarmed versions only; read no-alarm and undefined counts alongside them.
Exact post-burst recovery follows from original samples becoming identical again after the injected noise and the observation window moving beyond it; it does not prove noise rejection.

## Figure captions

- **report_fft_stems**: Measured strain and stress FFT stem plots for the condition selected by REPORT_FFT_GAMMA. Linear vertical axes use physical units, with no amplitude normalisation. Stems are actual FFT bins; dashed lines are nominal harmonics. Windowing and coherent-gain correction are unchanged. Bin heights are not direct target-frequency harmonic estimates.
- **report_feature_variation**: Selected within-record feature changes relative to the first complete window. First window is a plotting origin, not an established stable reference. Original conditions are separate records. All eight features remain in the complete figures and exports.
- **report_reference_sensitivity**: First confirmation time and departure sign across tested reference endpoints, with monitoring start held fixed. ND=no confirmation; U=undefined reference. All features and original conditions are displayed. Stability across endpoints is descriptive, not detection accuracy.
- **alarm_effect_size_audit**: Signed robust departure and relative feature change at each confirmation. Large scores may be caused by small reference scales; actual magnitude must be considered too.
