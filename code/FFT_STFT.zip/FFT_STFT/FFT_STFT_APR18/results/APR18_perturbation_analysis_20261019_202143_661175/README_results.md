# Client results guide

Stage B: paired feature responses to controlled additions; this stage does not evaluate alarms.

Read result_index.csv for all generated files and data_dictionary.csv for fields. PDF/PNG pairs contain the same figure; PDF is preferred for reports.
Numeric CSV fields retain missing values. ND in readable alarm tables means no confirmed reference departure in the monitoring interval; UNDEF means reference scores were undefined.
Original APR18 has no verified event labels: confirmations are reference departures, not validated material change or clotting times. Large robust scores can accompany tiny relative changes.
References are based on complete windows ending by the reference endpoint. Main monitoring uses outputs ending after that endpoint, and windows may overlap the reference time interval. Block 8 tests a stricter disjoint-interval alternative for coverage only.
Seeded noise versions share the same measured background. Counts and median/IQR summaries describe these simulations, not independent donor performance. Confirmation lags include alarmed versions only; read no-alarm and undefined counts alongside them.
Exact post-burst recovery follows from original samples becoming identical again after the injected noise and the observation window moving beyond it; it does not prove noise rejection.

## Figure captions

- **condition_comparison**: Separate panel metrics/scales: sustained paired percentage for gain and third-harmonic addition; median peak absolute paired percentage for noise. Gain strength is fractional original stress; additive strengths are added RMS/pre-onset centred stress RMS. Colour intensity cannot rank different panels directly.
- **report_noise_response_variability**: Selected features: median and IQR of peak absolute paired percentage response over noise seeds, separately by original condition and added RMS strength. Shading represents simulation variability conditional on shared backgrounds, not donor confidence intervals.
