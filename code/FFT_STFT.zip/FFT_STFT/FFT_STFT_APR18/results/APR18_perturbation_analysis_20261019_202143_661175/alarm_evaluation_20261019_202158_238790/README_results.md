# Client results guide

Stage C: controlled-perturbation alarms and parameter sensitivity. No pre-injection alarm evaluation is performed; monitoring begins after the configured start.

Read result_index.csv for all generated files and data_dictionary.csv for fields. PDF/PNG pairs contain the same figure; PDF is preferred for reports.
Numeric CSV fields retain missing values. ND in readable alarm tables means no confirmed reference departure in the monitoring interval; UNDEF means reference scores were undefined.
Original APR18 has no verified event labels: confirmations are reference departures, not validated material change or clotting times. Large robust scores can accompany tiny relative changes.
References are based on complete windows ending by the reference endpoint. Main monitoring uses outputs ending after that endpoint, and windows may overlap the reference time interval. Block 8 tests a stricter disjoint-interval alternative for coverage only.
Seeded noise versions share the same measured background. Counts and median/IQR summaries describe these simulations, not independent donor performance. Confirmation lags include alarmed versions only; read no-alarm and undefined counts alongside them.
Exact post-burst recovery follows from original samples becoming identical again after the injected noise and the observation window moving beyond it; it does not prove noise rejection.

## Figure captions

- **report_noise_alarm_counts**: First-confirmed alarm counts / seeded versions for every condition, strength and feature. A count includes background departures too; consult paired categories. Undefined references are identified in the raw status table.
- **report_paired_alarm_categories**: Paired outcomes against unchanged original records, including new, earlier, same, later and removed alarms. Stacked proportions pool configured conditions/strengths per feature; perturbation types have different numbers of versions. These are not independent donor rates.
- **report_noise_parameter_sensitivity**: Noise case-feature versions with confirmed alarms / all configured versions. Aggregated over original conditions, strengths and seeds per feature, at the primary reference endpoint. U denotes undefined-scale versions. All panels share a 0-to-1 colour scale. Original-background and new-alarm counts remain in noise_parameter_summary.csv.
