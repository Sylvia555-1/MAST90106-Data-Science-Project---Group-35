# Start here: Team35 FFT / STFT client handover

This package contains two executed, standalone notebooks, the supplied synthetic benchmark inputs, and the outputs regenerated from those inputs.

## Run

1. Extract the entire archive. Keep the notebooks beside metadata.json and the observable/ and truth/ folders.
2. Open either notebook in Jupyter with a Python 3 kernel. The verification environment used Python 3.12; requirements.txt records the analysis dependency versions used here. A Jupyter installation is additionally needed to interact with the notebooks.
3. Read Setup. DATA_DIR = Path(".") assumes the working directory is this extracted folder. Otherwise set DATA_DIR to its absolute path.
4. Use Restart Kernel and Run All. Each notebook is independent. No separate helper scripts are required.
5. Read results/<new timestamped run>/README_results.md and result_index.csv. Use PDF for report insertion and PNG for quick viewing. Complete numeric CSV tables remain available for further research.

## Which notebook?

- FFT_synthetic.ipynb: inspect discrete whole-record frequency bins and directly estimated early/late target harmonics. It does not calculate detected change times.
- STFT_synthetic.ipynb: compute eight local features, calibrate a full-control reference, confirm same-side threshold departures and evaluate first confirmations against the known injection onset.

Both use artificially modified signals with one shared measured APR18 background. They are not labelled clinical clotting records. README.md is the original benchmark provenance document; its inherited t-ESSTV workflow is not the implementation performed by these two notebooks.

## What changed

- Added English purpose, input, output and interpretation notes while retaining the original Block numbering.
- Centralised configurable scientific defaults in Setup. Scientific defaults are unchanged.
- Added consistent labels, panel lettering, discrete-bin FFT displays and separately exported report figures.
- Added readable primary delay/status matrices and per-feature confirmation audits. Numeric CSVs retain missing numeric values; presentation-only status matrices intentionally contain strings.
- Added parameter sensitivity and stationary short-window calibration figures. The full eight-feature research figures are retained.
- Added a per-run file index, field dictionary, captions, environment record and output checksums.
- Reduced selected long inline tables using VERBOSE_OUTPUT; full results are still exported.

## Main editable settings

In both notebooks: DATA_DIR, VERBOSE_OUTPUT, SAMPLING_HZ, OMEGA_RAD_S and PNG_DPI.
FFT: SEGMENT_CYCLES and SEGMENT_STARTS_S.
STFT: WINDOW_CYCLES, REQUESTED_HOP_S, Z_THRESHOLD, PERSISTENCE_S, LATE_WINDOW_START_S, sensitivity grids and comparison window lengths. REPORT_FEATURES contains four presentation choices only; all eight features remain analysed.

Changing any feature/window parameter requires a complete rerun and recalibration. These notebooks deliberately validate a named benchmark schema; applying the methods to a new experimental dataset requires reviewing data import, units, forcing frequency and validation assumptions. They are research notebooks, not a general clinical detector.

## Timing and status

A feature timestamp is the exclusive right edge of its complete observation window. Default STFT windows span 12.56 s with a 0.5 s output interval; 0.5 s is not detection latency. The primary confirmation requires same-side |z| >= 5 over at least 1 s (three adjacent default outputs).

- First crossing: earliest above-threshold output; it need not belong to the ultimately qualifying run.
- Confirmation: first output satisfying the persistence rule.
- Delay: confirmation minus known onset, only for post-onset first confirmations.
- ND: no confirmation by the final available output under that setting.
- PRE: the first confirmation preceded injection onset and is not replaced by a later confirmation.
- Earliest-across-feature timing is a descriptive summary, not validated feature fusion.

The reference uses the complete matched control: calibration is offline. Control alarm counts reuse the calibration record. Highly overlapping windows and three gain versions of one background are not independent samples. The short-window error figure tests one stationary harmonic mixture and 24 starting phases, not all signals or clinical events. Spectral entropy and bandwidth use different frequency grids across window lengths.

## Verification

All 11 source files match the supplied SHA256.json after restoring canonical filenames. The control truth file is included for provenance; neither detector reads it.

The original and revised FFT and STFT code cells were executed in order on these exact inputs. Numeric and identifier/status columns in 7 FFT and 23 STFT original exported tables were compared; all matched exactly. Notebook schemas, output-file hashes and report-figure layouts were checked. No fixture results are included. See verification_summary.json.

The supplied benchmark files are unchanged. The folder results/ contains only the revised runs. Re-execution creates new timestamped folders and does not overwrite prior results.


## Exact local filenames and layout

The two synthetic notebooks now require the actual project layout; they do not search alternative uploaded filenames or fall back to a flat input folder.

| Location | Files |
|---|---|
| Project root | FFT_synthetic.ipynb, STFT_synthetic.ipynb, metadata.json, README.md, SHA256.json, case_summary.csv |
| observable/ | control.csv, change_10pct.csv, change_20pct.csv, change_30pct.csv |
| truth/ | control_truth.csv, change_10pct_truth.csv, change_20pct_truth.csv, change_30pct_truth.csv |

The separate original-data notebook is named STFT_FFT_ON_APR18.ipynb and uses APR18.xlsx. Both belong beside the synthetic notebooks in the user's project. They are not needed by the synthetic analysis and are not included in this synthetic handover archive.

Keep the existing project files and folders. Replace only the two synthetic notebooks when applying this update to your project. DATA_DIR should refer to the common project root. No dataset files need to be renamed or moved.
