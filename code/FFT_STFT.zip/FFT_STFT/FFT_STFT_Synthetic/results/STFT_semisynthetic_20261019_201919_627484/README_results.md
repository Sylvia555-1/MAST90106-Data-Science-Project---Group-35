# Results guide

STFT confirmation-delay evaluation on artificial gain-change signals with a shared APR18 background. Read control/pre-onset counts alongside delays.

## Start here

Open result_index.csv for filenames and intended uses. All figure pairs contain identical content: PDF for reports, PNG for quick viewing.
Open data_dictionary.csv for table fields. CSV missing numeric values remain blank. ND in readable notebook tables means no confirmation by the last available window; PRE means the first confirmation preceded onset. Neither is zero delay.

## Interpretation

Paired differences compare a changed record with the matched control at the same time. Robust scores compare a feature with the frozen control distribution. They are different quantities.
Overlapping windows, gain cases and shared backgrounds are not independent donor observations. Calibration-record alarm counts are not independent false-alarm rates.
The FFT notebook does not estimate change times. STFT confirmation times use the exclusive window end and include persistence; earliest-across-feature summaries are descriptive, not validated fusion.

## Figure captions

- **feature_trajectories**: Eight local stress features of the synthetic gain benchmark. Each point summarises a 12.56 s periodic-Hann window, plotted at its exclusive end; update interval 0.5 s. Dashed line: prescribed onset. Separate y scales.
- **paired_feature_responses**: Eight paired percentage responses, 100*(case-control)/control in the same window. These isolate injected effects for inspection and are not the robust scores used by the detector.
- **alarm_scores**: Eight robust feature scores using separate full-control medians and 1.4826*MAD scales. Circles show first confirmed same-side alarms, not first crossings. Dashed horizontal lines mark the threshold; vertical line marks known onset. Calibration is offline.
- **window_comparison**: Scores and first confirmations for each configured observation length. Columns share y limits; each window length has a separate full-control reference. Missing markers do not mean zero delay. Entropy grids differ by length.
- **report_paired_responses**: Selected paired feature responses (selection affects presentation only). Dashed line marks prescribed onset. Each percentage compares changed signal with matched control in the same complete window. All eight features are retained in numeric exports.
- **report_alarm_scores**: Selected robust scores; control/gain colours are fixed across figures. Same-side threshold 5 and persistence 1 s. Circles: first confirmations at exclusive window ends. Full matched-control calibration is offline, not prospective validation.
- **report_sensitivity**: Threshold/persistence sensitivity. Counts of control confirmed features and pre-onset case-feature pairs are shown beside descriptive earliest post-onset delays. The primary setting is outlined. ND means no post-onset first confirmation among eligible features; per-feature PRE/ND states are in exported tables. Counts are not independent false-alarm rates. Each panel uses its own colour scale.
- **report_short_window_calibration**: Maximum absolute relative error over the configured starting phases of one known stationary harmonic mixture. Logarithmic vertical axis. Phase tests are not independent donor replicates; errors do not establish general event-detection performance.
