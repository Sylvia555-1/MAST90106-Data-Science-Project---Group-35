# Results guide

FFT spectral interpretation on artificial gain-change signals using one APR18 background. No change detector is applied.

## Start here

Open result_index.csv for filenames and intended uses. All figure pairs contain identical content: PDF for reports, PNG for quick viewing.
Open data_dictionary.csv for table fields. CSV missing numeric values remain blank. ND in readable notebook tables means no confirmation by the last available window; PRE means the first confirmation preceded onset. Neither is zero delay.

## Interpretation

Paired differences compare a changed record with the matched control at the same time. Robust scores compare a feature with the frozen control distribution. They are different quantities.
Overlapping windows, gain cases and shared backgrounds are not independent donor observations. Calibration-record alarm counts are not independent false-alarm rates.
The FFT notebook does not estimate change times. STFT confirmation times use the exclusive window end and include persistence; earliest-across-feature summaries are descriptive, not validated fusion.

## Figure captions

- **time_domain**: Synthetic benchmark input strain, observed stress and paired stress difference. Dashed line: prescribed injection onset. Differences are inspection quantities, not detector inputs.
- **full_record_fft**: Whole-record, periodic-Hann, coherent-gain-corrected FFT amplitudes as stems with round markers. Separate strain/stress panels use linear axes and their own units. No bins are joined and no spectrum is amplitude-normalised.
- **late_harmonic_comparison**: Late-segment changes relative to the matched control in the same segment. Actual bounds are in analysis_segments.csv. Harmonic amplitudes and ratios use separate scales; the ratio panel spans -1% to +1%. No independent-repeat uncertainty is implied.
- **report_fft_input_response**: Whole-record FFT stem plots: common input strain on the left and control stress on the right. Linear vertical axes retain separate physical units; no amplitude normalisation is applied. Each stem is one FFT bin. Dashed lines mark nominal f0, 3f0 and 5f0, not additional measurements. Finite-window bin peaks are not exact target-frequency harmonic amplitudes.
- **report_fft_gain_spectra**: Separate stem panels for control and each gain case, with common linear amplitude limits in Pa. Full records combine pre/post-onset data and cannot localise injection onset.
