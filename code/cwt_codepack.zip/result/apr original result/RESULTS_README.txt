APR18 original LAOS CWT results

Scope
-----
- Six omega=1 rad/s LAOS records: Gamma 0.5, 1, 5, 10, 50 and 100.
- Each block's first row was removed as the fixed startup spike.
- Uniform grid: 50 Hz; two-cycle primary window; 0.5 s output step.
- This source has no labelled change time or clotting point, so no detection delay is reported.

Files to inspect first
----------------------
1. 02_cwt_scalograms.png: time-frequency structure within each condition.
2. 03_harmonic_summary.png: I1, I3, I5 and harmonic ratios across Gamma.
3. 04_feature_stability.png: within-record temporal variability.
4. 05_method_agreement.png: CWT amplitude versus same-window harmonic regression.
5. 06_calibration.png: known-signal estimator error for one and two cycles.

Quick numerical checks
----------------------
- Number of analysed conditions: 6
- Two-cycle I1 robust CV range: 0.331% to 4.215%
- Largest absolute two-cycle CWT/projection median difference: 17.386%
- Largest two-cycle mixed-harmonic calibration error: 4.091%

Interpretation boundary
-----------------------
These outputs show repeatability and method agreement inside the supplied records. They do not by
themselves identify a gel point, clotting time, diagnostic threshold, or prospective false-alarm rate.
