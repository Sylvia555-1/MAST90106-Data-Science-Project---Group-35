# CWT Analysis Pack

## Scripts and outputs

| Script | Analysis | Output folder |
| --- | --- | --- |
| `cwt_apr18_original.py` | CWT analysis of the original measured APR18 LAOS data: harmonic extraction, feature stability, and window-length comparison. No known transition time is assumed. | `result/apr original result/` |
| `cwt_apr18_v2.py` | CWT analysis of the APR18 semi-synthetic experiment: detection of injected 10%, 20%, and 30% amplitude changes, with detection delays compared against stored STFT reference results. | `result/sythetic result/` |

The original-data script also creates `result/apr original result.zip`.

## Datasets

All paths below are relative to `pack/`.

| File or folder | Experiment and use |
| --- | --- |
| `dataset/APR18 SS SAOS STEPS LAOS UDLAOS.xlsx` | Original measured APR18 data. The original-data script reads the `LAOS` worksheet. This is an Excel workbook, not a CSV file. |
| `dataset/apr18_semisynthetic_laos_v2/` | APR18 semi-synthetic experiment. Its `observable/` folder contains `control.csv` and `change_10pct.csv`, `change_20pct.csv`, `change_30pct.csv`, used by `cwt_apr18_v2.py`. |
| `dataset/apr18_semisynthetic_laos_v2/case_summary.csv` | Ground-truth information for the semi-synthetic experiment: change onset at 15 seconds and the injected gain for each case. Used to evaluate detection delays. |

## Requirements and usage

Python 3 with **numpy, pandas, matplotlib, and openpyxl** is required.

1. Extract the entire ZIP and keep the folder structure unchanged.
2. Open a terminal in `pack/` and install the dependencies:

```bash
python -m pip install -r requirements.txt
```

3. Run either or both analyses:

```bash
python cwt_apr18_original.py
python cwt_apr18_v2.py
```

The scripts run independently. Input and output paths are anchored to the script location, so no path editing is needed. Result folders are created automatically inside `pack/result/`; rerunning overwrites files with the same names. The spelling `sythetic result` is intentional to match the configured folder name.
